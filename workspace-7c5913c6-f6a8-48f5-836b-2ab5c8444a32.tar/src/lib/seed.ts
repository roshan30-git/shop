import { db } from '@/lib/db'

const sampleProducts = [
  {
    title: "Classic Formal Shoes",
    description: "Elegant black formal shoes perfect for office wear and special occasions. Made with genuine leather for ultimate comfort.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400",
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop"
    ]),
    category: "FORMAL",
    price: 2999,
    discount: 20,
    stock: 15,
    sizes: JSON.stringify(["7", "8", "9", "10", "11"]),
    colors: JSON.stringify(["Black", "Brown"]),
    tags: JSON.stringify(["formal", "office", "leather", "comfort"]),
    featured: true
  },
  {
    title: "Sports Running Shoes",
    description: "High-performance running shoes with advanced cushioning technology. Perfect for athletes and fitness enthusiasts.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400",
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop"
    ]),
    category: "SPORTS",
    price: 3499,
    discount: 15,
    stock: 25,
    sizes: JSON.stringify(["6", "7", "8", "9", "10"]),
    colors: JSON.stringify(["Blue", "Red", "Black"]),
    tags: JSON.stringify(["sports", "running", "athletic", "performance"]),
    featured: true
  },
  {
    title: "Casual Sneakers",
    description: "Comfortable everyday sneakers with modern design. Perfect for casual outings and weekend wear.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=400",
      "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=400&h=400&fit=crop"
    ]),
    category: "MEN",
    price: 1999,
    discount: 10,
    stock: 30,
    sizes: JSON.stringify(["7", "8", "9", "10", "11"]),
    colors: JSON.stringify(["White", "Gray", "Navy"]),
    tags: JSON.stringify(["casual", "sneakers", "comfort", "everyday"]),
    featured: true
  },
  {
    title: "Women's Heels",
    description: "Stylish high heels for parties and special events. Comfortable design with elegant appearance.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=400",
      "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=400&h=400&fit=crop"
    ]),
    category: "WOMEN",
    price: 2499,
    discount: 25,
    stock: 20,
    sizes: JSON.stringify(["5", "6", "7", "8", "9"]),
    colors: JSON.stringify(["Red", "Black", "Nude"]),
    tags: JSON.stringify(["heels", "party", "elegant", "women"]),
    featured: true
  },
  {
    title: "Kids School Shoes",
    description: "Durable school shoes for children with comfortable fit and long-lasting quality.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=400",
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=400&h=400&fit=crop"
    ]),
    category: "KIDS",
    price: 1299,
    discount: 0,
    stock: 40,
    sizes: JSON.stringify(["3", "4", "5", "6"]),
    colors: JSON.stringify(["Black", "White"]),
    tags: JSON.stringify(["kids", "school", "durable", "comfortable"]),
    featured: false
  },
  {
    title: "Summer Sandals",
    description: "Breathable summer sandals perfect for beach and casual wear. Lightweight and comfortable.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1544441893-675973e31985?w=400",
      "https://images.unsplash.com/photo-1544441893-675973e31985?w=400&h=400&fit=crop"
    ]),
    category: "SANDALS",
    price: 899,
    discount: 30,
    stock: 50,
    sizes: JSON.stringify(["6", "7", "8", "9", "10"]),
    colors: JSON.stringify(["Brown", "Tan", "Black"]),
    tags: JSON.stringify(["sandals", "summer", "beach", "casual"]),
    featured: false
  },
  {
    title: "Men's Leather Jacket",
    description: "Premium quality leather jacket with modern cut. Perfect for bikers and fashion enthusiasts.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=400",
      "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=400&h=400&fit=crop"
    ]),
    category: "MEN",
    price: 5999,
    discount: 20,
    stock: 10,
    sizes: JSON.stringify(["M", "L", "XL", "XXL"]),
    colors: JSON.stringify(["Black", "Brown"]),
    tags: JSON.stringify(["jacket", "leather", "biker", "fashion"]),
    featured: true
  },
  {
    title: "Women's Handbag",
    description: "Elegant designer handbag with multiple compartments. Perfect for office and parties.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400",
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop"
    ]),
    category: "WOMEN",
    price: 3499,
    discount: 15,
    stock: 25,
    sizes: JSON.stringify(["One Size"]),
    colors: JSON.stringify(["Black", "Brown", "Beige"]),
    tags: JSON.stringify(["handbag", "designer", "elegant", "office"]),
    featured: true
  },
  {
    title: "Sports T-Shirt",
    description: "Moisture-wicking sports t-shirt for workouts and athletic activities.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1576995853123-5a10305d7c64?w=400",
      "https://images.unsplash.com/photo-1576995853123-5a10305d7c64?w=400&h=400&fit=crop"
    ]),
    category: "SPORTS",
    price: 599,
    discount: 10,
    stock: 60,
    sizes: JSON.stringify(["S", "M", "L", "XL"]),
    colors: JSON.stringify(["Blue", "Black", "Gray", "Red"]),
    tags: JSON.stringify(["t-shirt", "sports", "workout", "athletic"]),
    featured: false
  },
  {
    title: "Kids Backpack",
    description: "Colorful and spacious backpack for school. Multiple compartments with comfortable straps.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400",
      "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400&h=400&fit=crop"
    ]),
    category: "KIDS",
    price: 799,
    discount: 0,
    stock: 35,
    sizes: JSON.stringify(["One Size"]),
    colors: JSON.stringify(["Blue", "Pink", "Red", "Green"]),
    tags: JSON.stringify(["backpack", "school", "kids", "colorful"]),
    featured: false
  },
  {
    title: "Formal Shirt",
    description: "Premium cotton formal shirt perfect for office meetings and business events.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400",
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&h=400&fit=crop"
    ]),
    category: "FORMAL",
    price: 1499,
    discount: 25,
    stock: 45,
    sizes: JSON.stringify(["S", "M", "L", "XL", "XXL"]),
    colors: JSON.stringify(["White", "Blue", "Light Blue", "Pink"]),
    tags: JSON.stringify(["shirt", "formal", "office", "cotton"]),
    featured: false
  },
  {
    title: "Women's Dress",
    description: "Beautiful ethnic dress perfect for festivals and special occasions.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400",
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop"
    ]),
    category: "WOMEN",
    price: 3999,
    discount: 30,
    stock: 15,
    sizes: JSON.stringify(["S", "M", "L", "XL"]),
    colors: JSON.stringify(["Red", "Blue", "Green", "Yellow"]),
    tags: JSON.stringify(["dress", "ethnic", "festival", "traditional"]),
    featured: true
  },
  {
    title: "Sports Shorts",
    description: "Comfortable gym shorts for workouts and sports activities.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?w=400",
      "https://images.unsplash.com/photo-1586790170083-2a10305d7c64?w=400&h=400&fit=crop"
    ]),
    category: "SPORTS",
    price: 799,
    discount: 20,
    stock: 40,
    sizes: JSON.stringify(["S", "M", "L", "XL"]),
    colors: JSON.stringify(["Black", "Blue", "Gray", "Navy"]),
    tags: JSON.stringify(["shorts", "sports", "gym", "workout"]),
    featured: false
  },
  {
    title: "Flip Flops",
    description: "Comfortable flip flops for daily wear and beach outings.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1513105704435-8516a8003b9e?w=400",
      "https://images.unsplash.com/photo-1513105704435-8516a8003b9e?w=400&h=400&fit=crop"
    ]),
    category: "SANDALS",
    price: 399,
    discount: 0,
    stock: 80,
    sizes: JSON.stringify(["6", "7", "8", "9", "10"]),
    colors: JSON.stringify(["Black", "Blue", "Red", "Green"]),
    tags: JSON.stringify(["flip-flops", "casual", "beach", "daily"]),
    featured: false
  },
  {
    title: "Kids T-Shirt",
    description: "Colorful cotton t-shirts for kids with fun prints and comfortable fit.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1569766203455-cc82aa5e9816?w=400",
      "https://images.unsplash.com/photo-1569766203455-cc82aa5e9816?w=400&h=400&fit=crop"
    ]),
    category: "KIDS",
    price: 399,
    discount: 10,
    stock: 50,
    sizes: JSON.stringify(["2-3Y", "4-5Y", "6-7Y", "8-9Y"]),
    colors: JSON.stringify(["Red", "Blue", "Yellow", "Green"]),
    tags: JSON.stringify(["t-shirt", "kids", "colorful", "cotton"]),
    featured: false
  },
  {
    title: "Men's Jeans",
    description: "Stylish denim jeans with perfect fit and modern design.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400",
      "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=400&fit=crop"
    ]),
    category: "MEN",
    price: 2499,
    discount: 15,
    stock: 35,
    sizes: JSON.stringify(["30", "32", "34", "36", "38"]),
    colors: JSON.stringify(["Blue", "Black", "Gray"]),
    tags: JSON.stringify(["jeans", "denim", "casual", "stylish"]),
    featured: true
  },
  {
    title: "Women's Sunglasses",
    description: "Trendy sunglasses with UV protection. Perfect accessory for summer.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1473496169904-658ba7c44d8a?w=400",
      "https://images.unsplash.com/photo-1473496169904-658ba7c44d8a?w=400&h=400&fit=crop"
    ]),
    category: "WOMEN",
    price: 1299,
    discount: 20,
    stock: 30,
    sizes: JSON.stringify(["One Size"]),
    colors: JSON.stringify(["Black", "Brown", "Pink"]),
    tags: JSON.stringify(["sunglasses", "accessory", "UV-protection", "trendy"]),
    featured: false
  },
  {
    title: "Sports Watch",
    description: "Digital sports watch with fitness tracking features and water resistance.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400",
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop"
    ]),
    category: "SPORTS",
    price: 2999,
    discount: 25,
    stock: 20,
    sizes: JSON.stringify(["One Size"]),
    colors: JSON.stringify(["Black", "Blue", "Red"]),
    tags: JSON.stringify(["watch", "digital", "fitness", "water-resistant"]),
    featured: true
  },
  {
    title: "Formal Trousers",
    description: "Premium formal trousers perfect for business meetings and office wear.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400",
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&h=400&fit=crop"
    ]),
    category: "FORMAL",
    price: 1999,
    discount: 10,
    stock: 25,
    sizes: JSON.stringify(["30", "32", "34", "36", "38"]),
    colors: JSON.stringify(["Black", "Gray", "Navy", "Khaki"]),
    tags: JSON.stringify(["trousers", "formal", "office", "business"]),
    featured: false
  },
  {
    title: "Women's Wallet",
    description: "Elegant leather wallet with multiple card slots and coin pocket.",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1627123420475-c091b0a564b9?w=400",
      "https://images.unsplash.com/photo-1627123420475-c091b0a564b9?w=400&h=400&fit=crop"
    ]),
    category: "WOMEN",
    price: 899,
    discount: 0,
    stock: 40,
    sizes: JSON.stringify(["One Size"]),
    colors: JSON.stringify(["Black", "Brown", "Pink", "Red"]),
    tags: JSON.stringify(["wallet", "leather", "accessory", "elegant"]),
    featured: false
  }
]

export async function seedProducts() {
  try {
    // Clear existing products
    await db.product.deleteMany()
    
    // Add sample products
    for (const product of sampleProducts) {
      await db.product.create({
        data: product
      })
    }
    
    console.log('Sample products seeded successfully!')
  } catch (error) {
    console.error('Error seeding products:', error)
  }
}

// Run if called directly
if (require.main === module) {
  seedProducts()
}