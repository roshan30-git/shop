'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ShoppingCart, Star, MapPin, Phone, Mail, Award, Users, Heart } from 'lucide-react'
import Link from 'next/link'

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/" className="text-2xl font-bold text-black">
                SuratTrendzz
              </Link>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <Link href="/products" className="text-gray-700 hover:text-black">Products</Link>
              <Link href="/about" className="text-black font-medium">About</Link>
              <Link href="/contact" className="text-gray-700 hover:text-black">Contact</Link>
            </div>

            <div className="flex items-center space-x-4">
              <Link href="/cart">
                <Button variant="outline" size="icon">
                  <ShoppingCart className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/admin">
                <Button variant="outline">Admin</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-gray-50 to-gray-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-black mb-6">
              About
              <span className="text-yellow-600"> SuratTrendzz</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Your trusted fashion destination in Varachha, Surat since 1995. 
              We believe in quality, style, and affordable pricing for every customer.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-black mb-6">Our Story</h2>
              <p className="text-gray-600 mb-4">
                Founded in 1995 by Mr. Surat Patel, SuratTrendzz started as a small fashion boutique in the heart of Varachha, Surat. 
                What began as a humble fashion store has grown into a trusted name that generations of families rely on for their fashion and footwear needs.
              </p>
              <p className="text-gray-600 mb-4">
                For over 25 years, we've been committed to providing high-quality fashion and footwear at prices that don't break the bank. 
                Our mission is simple: to ensure every customer walks out of our store with a smile on their face and style in their step.
              </p>
              <p className="text-gray-600 mb-6">
                Today, we continue to serve the Surat community with the same dedication and personal touch that made us famous. 
                from casual wear to formal attire, from sports shoes to traditional sandals - we have something for everyone.
              </p>
              <div className="flex gap-4">
                <Link href="/products">
                  <Button className="bg-black text-white hover:bg-gray-800">
                    Explore Our Collection
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button variant="outline">Visit Our Store</Button>
                </Link>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=600"
                alt="Sanju Footwear Store"
                className="rounded-lg shadow-lg w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-black mb-4">Our Values</h2>
            <p className="text-gray-600">The principles that guide everything we do</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-yellow-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Quality First</h3>
                <p className="text-gray-600">We never compromise on quality. Every pair of shoes is carefully selected for durability and comfort.</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-yellow-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Customer Care</h3>
                <p className="text-gray-600">Our customers are family. We provide personalized service and expert advice to help you find the perfect fit.</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-yellow-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Community Focus</h3>
                <p className="text-gray-600">We're proud to be a local Surat business, serving our community with integrity and trust for over 25 years.</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="h-8 w-8 text-yellow-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Affordable Pricing</h3>
                <p className="text-gray-600">Quality footwear shouldn't be expensive. We offer competitive prices without compromising on comfort or style.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-black mb-2">25+</div>
              <p className="text-gray-600">Years in Business</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-black mb-2">50,000+</div>
              <p className="text-gray-600">Happy Customers</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-black mb-2">500+</div>
              <p className="text-gray-600">Footwear Styles</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-black mb-2">4.8★</div>
              <p className="text-gray-600">Customer Rating</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-black mb-4">What Our Customers Say</h2>
            <p className="text-gray-600">Real reviews from real customers</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "I've been buying shoes from Sanju Footwear for 10 years. The quality is always excellent and the prices are unbeatable. Highly recommended!"
                </p>
                <div className="font-semibold">Rakesh P.</div>
                <div className="text-sm text-gray-500">Varachha, Surat</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "Great collection of formal shoes! The staff is very helpful and helped me find the perfect pair for my office. Will definitely come back."
                </p>
                <div className="font-semibold">Priya S.</div>
                <div className="text-sm text-gray-500">Adajan, Surat</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "Best place to buy school shoes for kids. They have good quality shoes that last the entire school year. Very satisfied with the purchase."
                </p>
                <div className="font-semibold">Anita M.</div>
                <div className="text-sm text-gray-500">Piplod, Surat</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-black mb-4">Visit Our Store</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Experience the Sanju Footwear difference in person. Visit our store in Varachha, Surat and let our expert staff help you find the perfect pair.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" className="bg-black text-white hover:bg-gray-800">
                Get Directions
              </Button>
            </Link>
            <Link href="/products">
              <Button size="lg" variant="outline">
                Shop Online
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">SuratTrendzz</h3>
              <p className="text-gray-400">Your trusted fashion destination in Varachha, Surat.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/products" className="hover:text-white">Products</Link></li>
                <li><Link href="/about" className="hover:text-white">About Us</Link></li>
                <li><Link href="/contact" className="hover:text-white">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact Info</h4>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center"><MapPin className="h-4 w-4 mr-2" /> Varachha, Surat</li>
                <li className="flex items-center"><Phone className="h-4 w-4 mr-2" /> +91 98765 43210</li>
                <li className="flex items-center"><Mail className="h-4 w-4 mr-2" /> info@sanjufootwear.com</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <a href="https://www.instagram.com/surattrendzz_official/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white">
                  Instagram
                </a>
                <a href="https://wa.me/message" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white">
                  WhatsApp
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 SuratTrendzz. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}