import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const featured = searchParams.get('featured')
    const search = searchParams.get('search')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '12')
    const skip = (page - 1) * limit

    let whereClause: any = {}

    if (category) {
      whereClause.category = category.toUpperCase()
    }

    if (featured === 'true') {
      whereClause.featured = true
    }

    if (search) {
      whereClause.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
        { tags: { contains: search } }
      ]
    }

    const products = await db.product.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    })

    const total = await db.product.count({ where: whereClause })

    const formattedProducts = products.map(product => ({
      ...product,
      images: product.images,
      sizes: product.sizes,
      colors: product.colors,
      tags: product.tags,
    }))

    return NextResponse.json(formattedProducts)
  } catch (error) {
    console.error('Error fetching products:', error)
    return NextResponse.json(
      { error: 'Failed to fetch products' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      title,
      description,
      images,
      category,
      price,
      discount,
      stock,
      sizes,
      colors,
      tags,
      featured
    } = body

    if (!title || !description || !category || !price) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const product = await db.product.create({
      data: {
        title,
        description,
        images: JSON.stringify(images || []),
        category: category.toUpperCase(),
        price: parseFloat(price),
        discount: parseFloat(discount) || 0,
        stock: parseInt(stock) || 0,
        sizes: JSON.stringify(sizes || []),
        colors: JSON.stringify(colors || []),
        tags: JSON.stringify(tags || []),
        featured: featured || false,
      },
    })

    return NextResponse.json(product, { status: 201 })
  } catch (error) {
    console.error('Error creating product:', error)
    return NextResponse.json(
      { error: 'Failed to create product' },
      { status: 500 }
    )
  }
}